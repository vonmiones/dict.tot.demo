<?php 
global $config;
$config["title"] = "";

$config["dbhost"] = "localhost";
$config["dbport"] = "3306";
$config["dbname"] = "dict_tot";
$config["dbuser"] = "root";
$config["dbpass"] = "";

$config["theme-default"] = "default";
$config["libs"] = "";
$config["apps"] = "";

$config["logs"] = "";